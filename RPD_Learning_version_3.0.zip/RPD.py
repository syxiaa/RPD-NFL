from relative_probabilty_density.kliep import KLIEP
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.cluster import KMeans
from sklearn.svm import SVC
import pandas as pd
import numpy as np



class RPD():

    def __init__(self, sigma_chosen=1, method="linear_LR", rpd_method="KLIEP", C=1.0, alpha=0.5):
        """
        参数初始化
        :param sigma_chosen: int, KLIEP中核宽度
        :param method: String, 检验正确的方法，目前可以选择的有：linear_LR,kernel_LR,linear_SVM,kernel_SVM
        :param rpd_method: String, 计算RPD的方式,目前可以选择的有：KLIEP, classifier
        :param C: float, SVM中的惩罚因子
        :param alpha: float,(0, 1],RPD中的一个参数,防止过滤太多样本
        """
        self.C = C
        self.alpha = alpha
        self.rpd_method = rpd_method
        self.method = method
        self.sigma_chosen=sigma_chosen
        self.best_acc = 0
        self.posi_filter = True
        self.nega_filter = True
        self.clean_train = pd.DataFrame()


    def cal_rpd_kliep(self, x):
        """The RPD is calculated by KLIEP"""

        def cal_density_ratio(x, choice="positive"):
            """得到的y=-1的rpd"""
            model = KLIEP()

            positive_x = x[x[:, 0] == 1, 1:]
            negative_x = x[x[:, 0] == -1, 1:]

            # 通过KLIEP计算密度比
            if choice == "positive":
                density_ratio, _ = model.fit(positive_x.T, negative_x.T, sigma_chosen=self.sigma_chosen)
            else:
                density_ratio, _ = model.fit(negative_x.T, positive_x.T, sigma_chosen=self.sigma_chosen)
            return density_ratio

        nega_rpd = cal_density_ratio(x, "negative")  # negative RPD
        posi_rpd = cal_density_ratio(x, "positive")  # positive RPD

        RPD = []
        ne_index = 0
        po_index = 0

        for i in range(len(x)):
            if x[i, 0] == -1:
                RPD.append(nega_rpd[ne_index])
                ne_index += 1
            elif x[i, 0] == 1:
                RPD.append(posi_rpd[po_index])
                po_index += 1

        RPD = np.array(RPD).reshape(-1, 1)
        return RPD


    def cal_rpd_classifier(self, x):
        """The RPD is calculated by classifier"""

        if self.method == "kernel_LR":
            model = LogisticRegression()
            rbf_train = rbf_kernel(x[:, 1:], x[:, 1:])
            model.fit(rbf_train[:, 1:], x[:, 0])
            proba = model.predict_proba(rbf_train[:, 1:])

        else:
            if self.method == "linear_LR":
                model = LogisticRegression()

            elif self.method == "linear_SVM":
                model = SVC(kernel="linear", probability=True, C=self.C)

            elif self.method == "kernel_SVM":
                model = SVC(kernel="rbf", probability=True, C=self.C)
            else:
                print("%s方法不存在！" % (self.method))
                return None
            model.fit(x[:, 1:], x[:, 0])
            proba = model.predict_proba(x[:, 1:])

        posi_num = np.count_nonzero(x[:, 0] == 1)
        nega_num = np.count_nonzero(x[:, 0] == -1)
        ratio = [posi_num / nega_num, nega_num / posi_num]
        RPD = []

        for i in range(x.shape[0]):
            if x[i, 0] == 1:
                RPD.append(ratio[0] * proba[i, 0] / proba[i, 1])
            elif x[i, 0] == -1:
                RPD.append(ratio[1] * proba[i, 1] / proba[i, 0])
        RPD = np.array(RPD).reshape(-1, 1)
        return RPD


    def method_choice(self, train, test):
        """Select different loss function and return the corresponding precision"""

        if self.method == "linear_LR":
            accuracy = self.linear_LR(train, test)
        elif self.method == "kernel_LR":
            accuracy = self.kernel_LR(train, test)
        elif self.method == "linear_SVM":
            accuracy = self.linear_SVM(train, test)
        elif self.method == "kernel_SVM":
            accuracy = self.kernel_SVM(train, test)
        else:
            print("%s方法不存在！" % (self.method))
            return None

        return accuracy


    def linear_LR(self, train, test):
        """linear-Logistic regression accuracy"""

        model = LogisticRegression()
        model.fit(train[:, 1:], train[:, 0])
        accuracy = model.score(test[:, 1:], test[:, 0])
        accuracy = accuracy * 100
        return accuracy

    def kernel_LR(self, train, test):
        """kernel_logistic regression accuracy"""

        model = LogisticRegression()
        rbf_train = rbf_kernel(train[:, 1:], train[:, 1:])
        rbf_test = rbf_kernel(test[:, 1:], train[:, 1:])

        model.fit(rbf_train[:, 1:], train[:, 0])
        accuracy = model.score(rbf_test[:, 1:], test[:, 0])
        accuracy = accuracy * 100
        return accuracy

    def linear_SVM(self, train, test):
        """linear_hinge accuracy"""

        model = SVC(kernel="linear", C=self.C)
        model.fit(train[:, 1:], train[:, 0])
        accuracy = model.score(test[:, 1:], test[:, 0])
        accuracy = accuracy * 100
        return accuracy

    def kernel_SVM(self, train, test):
        """kernel_hinge accuracy"""

        model = SVC(kernel="rbf", C=self.C)
        model.fit(train[:, 1:], train[:, 0])
        accuracy = model.score(test[:, 1:], test[:, 0])
        accuracy = accuracy * 100
        return accuracy

    def Filter_significant_noise(self, x):
        """
        通过k-Means过滤掉显著噪声
        :param x: DataFrame, 并且标签在第一列
        """

        model = KMeans(n_clusters=2, n_jobs=1)
        model.fit(x["RPD"].values.reshape(-1, 1))

        center = model.cluster_centers_  # 返回质心
        x['labels'] = model.labels_      # 返回每个样本的标签（簇的标签）
        col = x.columns

        thre_value_ind = np.argmin(center)
        clean_train_temp = x.ix[x["labels"] == thre_value_ind, col[:-2]]
        noise_train = x.ix[x["labels"] != thre_value_ind, col[:-1]]

        clean_train = self.clean_train.append(clean_train_temp)
        return noise_train, clean_train


    def fit(self, train, test):
        """
        Self filtration based on relative probability density
        :param train: numpy, 标签在第一列，标签为-1，1
        :param test: numpy, 标签在第一列，标签为-1，1
        """

        # 初始化
        train = pd.DataFrame(train)

        # 计算每个样本的RPD值
        if self.rpd_method == "KLIEP":  # The RPD was calculated by KLIEP
            RPD = self.cal_rpd_kliep(train.values)
        else:                           # The RPD was calculated by classifier
            RPD = self.cal_rpd_classifier(train.values)

        train["RPD"] = RPD
        positive_train = train.ix[train[0] == 1, :]
        negative_train = train.ix[train[0] == -1, :]
        posi_thre = len(positive_train) * self.alpha  # 正类数据集阈值
        nega_thre = len(negative_train) * self.alpha  # 负类数据集阈值

        # 提高程序的容错能力
        if len(positive_train) <= 1:
            self.posi_filter = False
        if len(negative_train) <= 1:
            self.nega_filter = False
        if self.posi_filter == False or self.nega_filter == False:
            print("数据为空！")
            return None

        # 正类干净数据初始化，当噪声数据小于正类阈值时，停止初始化
        while True:
            positive_train, self.clean_train = self.Filter_significant_noise(positive_train)
            posi_train_len = len(positive_train)
            if posi_train_len <= 1:
                self.posi_filter = False
                break
            if posi_train_len < posi_thre:
                break

        # 负类干净数据初始化
        while True:
            negative_train, self.clean_train = self.Filter_significant_noise(negative_train)
            nega_train_len = len(negative_train)
            if nega_train_len <= 1:
                self.nega_filter = False
                break
            if nega_train_len < nega_thre:
                break

        if self.nega_filter == False and self.posi_filter == False:
            return self.method_choice(self.clean_train.values, test)

        # 过滤显著噪声
        while True:
            if self.posi_filter == True:  # 过滤正类显著噪声
                positive_train, temp_clean_train = self.Filter_significant_noise(positive_train)
                temp_acc = self.method_choice(temp_clean_train.values, test)  # 测试正确率
                if self.best_acc < temp_acc:
                    self.best_acc = temp_acc
                    self.clean_train = temp_clean_train
                elif self.best_acc > temp_acc:
                    self.posi_filter = False
                if len(positive_train) <= 1:
                    self.posi_filter = False

            if self.nega_filter == True:  # 过滤负类显著噪声
                negative_train, temp_clean_train = self.Filter_significant_noise(negative_train)
                temp_acc = self.method_choice(temp_clean_train.values, test)
                if self.best_acc < temp_acc:
                    self.best_acc = temp_acc
                    self.clean_train = temp_clean_train
                elif self.best_acc > temp_acc:
                    self.nega_filter = False
                if len(negative_train) <= 1:
                    self.nega_filter = False

            if self.posi_filter == False and self.nega_filter == False:
                break
        return self.best_acc
























