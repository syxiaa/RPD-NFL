from relative_probabilty_density.kliep import KLIEP
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.cluster import KMeans
from sklearn.svm import SVC
import pandas as pd
import numpy as np




def cal_rpd_kliep(data, sigma_chosen=1):
    """The RPD is calculated by KLIEP"""

    def cal_rpd_negative(data, sigma_chosen=1):
        """得到的y=-1的rpd"""

        model = KLIEP()
        positive_data = data[data[:, 0] == 1, 1:]
        negative_data = data[data[:, 0] == -1, 1:]
        # 通过KLIEP计算密度比
        nega_rpd, _ = model.fit(negative_data.T, positive_data.T, sigma_chosen=sigma_chosen)
        return nega_rpd

    def cal_rpd_positive(data, sigma_chosen=1):
        """得到y=+1类的rpd"""

        model = KLIEP()
        positive_data = data[data[:, 0] == 1, 1:]
        negative_data = data[data[:, 0] == -1, 1:]
        # 通过KLIEP计算密度比
        posi_rpd, _ = model.fit(positive_data.T, negative_data.T, sigma_chosen=sigma_chosen)
        return posi_rpd

    nega_rpd = cal_rpd_negative(data, sigma_chosen=sigma_chosen) # negative number
    posi_rpd = cal_rpd_positive(data, sigma_chosen=sigma_chosen) # positive number

    RPD = []
    ne_index = 0
    po_index = 0

    for i in range(len(data)):
        if data[i, 0] == -1:
            RPD.append(nega_rpd[ne_index])
            ne_index += 1
        elif data[i, 0] == 1:
            RPD.append(posi_rpd[po_index])
            po_index += 1

    RPD = np.array(RPD).reshape(-1, 1)
    return RPD




def cal_rpd_classifier(data, method, C=1.0):
    """The RPD is calculated by classifier"""

    if method == "kernel_LR":
        model = LogisticRegression()
        rbf_train = rbf_kernel(data[:, 1:], data[:, 1:])
        model.fit(rbf_train[:, 1:], data[:, 0])
        proba = model.predict_proba(rbf_train[:, 1:])

    else:
        if method == "linear_LR":
            model = LogisticRegression()

        elif method == "linear_SVM":
            model = SVC(kernel="linear", probability=True, C=C)

        elif method == "kernel_SVM":
            model = SVC(kernel="rbf", probability=True, C=C)
        else:
            print("%s方法不存在！" % (method))
            return None
        model.fit(data[:, 1:], data[:, 0])
        proba = model.predict_proba(data[:, 1:])

    posi_num = np.count_nonzero(data[:, 0] == 1)
    nega_num = np.count_nonzero(data[:, 0] == -1)
    ratio = [posi_num / nega_num, nega_num / posi_num]
    RPD = []

    for i in range(data.shape[0]):
        if data[i, 0] == 1:
            RPD.append(ratio[0] * proba[i, 0] / proba[i, 1])
        elif data[i, 0] == -1:
            RPD.append(ratio[1] * proba[i, 1] / proba[i, 0])
    RPD = np.array(RPD).reshape(-1, 1)
    return RPD



def method_choice(train, test, method, C=1.0):
    """Select different loss function and return the corresponding precision"""

    if method == "linear_LR":
        accuracy = linear_LR(train, test)
    elif method == "kernel_LR":
        accuracy = kernel_LR(train, test)
    elif method == "linear_SVM":
        accuracy = linear_SVM(train, test, C=C)
    elif method == "kernel_SVM":
        accuracy = kernel_SVM(train, test, C=C)
    else:
        print("%s方法不存在！" % (method))
        return None

    return accuracy




def linear_LR(train, test):
    """linear-Logistic regression accuracy"""

    model = LogisticRegression()
    model.fit(train[:, 1:], train[:, 0])
    accuracy = model.score(test[:, 1:], test[:, 0])
    accuracy = accuracy * 100
    return accuracy


def kernel_LR(train, test):
    """kernel_logistic regression accuracy"""

    model = LogisticRegression()
    rbf_train = rbf_kernel(train[:, 1:], train[:, 1:])
    rbf_test = rbf_kernel(test[:, 1:], train[:, 1:])

    model.fit(rbf_train[:, 1:], train[:, 0])
    accuracy = model.score(rbf_test[:, 1:], test[:, 0])
    accuracy = accuracy * 100
    return accuracy


def linear_SVM(train, test, C=1.0):
    """linear_hinge accuracy"""

    model = SVC(kernel="linear", C=C)
    model.fit(train[:, 1:], train[:, 0])
    accuracy = model.score(test[:, 1:], test[:, 0])
    accuracy = accuracy * 100
    return accuracy


def kernel_SVM(train, test, C=1.0):
    """kernel_hinge accuracy"""

    model = SVC(kernel="rbf", C=C)
    model.fit(train[:, 1:], train[:, 0])
    accuracy = model.score(test[:, 1:], test[:, 0])
    accuracy = accuracy * 100
    return accuracy



def self_filter(train, clean_train):
    """通过k-Means过滤掉显著噪声"""

    model = KMeans(n_clusters=2, n_jobs=1)
    model.fit(train["RPD"].values.reshape(-1, 1))

    center = model.cluster_centers_          # 返回质心
    train['labels'] = model.labels_          # 返回每个样本的标签（簇的类别）
    col = train.columns

    thre_value_ind = np.argmin(center)
    clean_train_temp = train.ix[train["labels"] == thre_value_ind, col[:-2]]
    noise_train = train.ix[train["labels"] != thre_value_ind, col[:-1]]

    # clean_train_temp = train.ix[train["labels"] == thre_value_ind, :]
    # noise_train = train.ix[train["labels"] != thre_value_ind, :]
    # clean_train_temp.drop(["RPD", "labels"], axis=1, inplace=True)
    # noise_train.drop(["labels"], axis=1, inplace=True)

    clean_train = clean_train.append(clean_train_temp)
    return noise_train, clean_train




def relative_proba_density(train, test, method="linear_LR", rpd_method="KLIEP", sigma_chosen=1, C=1.0, alpha=0.5):
    """Self filtration based on relative probability density"""

    # 初始化
    best_acc = 0
    train = pd.DataFrame(train)
    clean_train = pd.DataFrame()

    # 计算每个样本的RPD值
    if rpd_method == "KLIEP":  # The RPD was calculated by KLIEP
        RPD = cal_rpd_kliep(train.values, sigma_chosen=sigma_chosen)
    else:                      # The RPD was calculated by classifier
        RPD = cal_rpd_classifier(train.values, method, C=C)

    train["RPD"] = RPD
    positive_train = train.ix[train[0] == 1, :]
    negative_train = train.ix[train[0] == -1, :]
    posi_thre = len(positive_train) * alpha     # 正类数据集阈值
    nega_thre = len(negative_train) * alpha     # 负类数据集阈值
    filter_1 = True
    filter_2 = True

    # 提高程序的容错能力
    if len(positive_train) <= 1:
        filter_1 = False
    if len(negative_train) <= 1:
        filter_2 = False
    if filter_1 == False or filter_2 == False:
        print("数据为空！")
        return None

    # 正类干净数据初始化，当噪声数据小于正类阈值时，停止初始化
    while True:
        positive_train, clean_train = self_filter(positive_train, clean_train)
        posi_train_len = len(positive_train)
        if posi_train_len <= 1:        # "噪声样本"的个数 <= 1
            filter_1 = False
            break
        if posi_train_len < posi_thre: # "噪声样本"的个数 <= 正类阈值
            break

    # 负类干净数据初始化
    while True:
        negative_train, clean_train = self_filter(negative_train, clean_train)
        nega_train_len = len(negative_train)
        if nega_train_len <= 1:        # "噪声样本"的个数 <= 1
            filter_2 = False
            break
        if nega_train_len < nega_thre: # "噪声样本"的个数 <= 负类阈值
            break

    if filter_1 == False and filter_2 == False:
        return method_choice(clean_train.values, test, method, C=C)

    # 过滤显著噪声
    while True:
        if filter_1 == True:              # 过滤正类显著噪声
            positive_train, temp_clean_train = self_filter(positive_train, clean_train)
            temp_acc = method_choice(temp_clean_train.values, test, method, C=C)  # 测试正确率
            if best_acc < temp_acc:
                best_acc = temp_acc
                clean_train = temp_clean_train
            elif best_acc > temp_acc:     # 准确率下降
                filter_1 = False
            if len(positive_train) <= 1:
                filter_1 = False

        if filter_2 == True:              # 过滤负类显著噪声
            negative_train, temp_clean_train = self_filter(negative_train, clean_train)
            temp_acc = method_choice(temp_clean_train.values, test, method, C=C)
            if best_acc < temp_acc:
                best_acc = temp_acc
                clean_train = temp_clean_train
            elif best_acc > temp_acc:
                filter_2 = False
            if len(negative_train) <= 1:
                filter_2 = False

        if filter_1 == False and filter_2 == False:
            break
    return best_acc


