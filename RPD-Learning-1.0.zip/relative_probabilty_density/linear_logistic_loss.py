from relative_probabilty_density.relative_probability_density import relative_proba_density
from relative_probabilty_density.tools import load_data, cal_sample_weight
from relative_probabilty_density.relative_density import relative_density
from sklearn.linear_model import LogisticRegression
import pandas as pd
import numpy as np



def linear_LR(train, test, sample_weight=None):
    """linear-logistic accuracy"""

    model = LogisticRegression()
    if sample_weight is None:
        model.fit(train[:, 1:], train[:, 0])
    else:                              # importance reweighting
        model.fit(train[:, 1:], train[:, 0], sample_weight=sample_weight)
    acc = model.score(test[:, 1:], test[:, 0])
    acc *= 100
    return acc


def main_train(key, noise, sigma_chosen=1, divide_num=10):
    """在指定噪声率下，训练，并返回其精度、标准差"""

    temp_acc = []
    print(key, "数据集 ", "噪声率为：", noise, sep="")

    for i in range(divide_num):
        train, test = load_data(key, 0.25, noise)
        sample_weight = cal_sample_weight(train, noise, sigma_chosen=sigma_chosen) # sample_weight

        acc0 = linear_LR(train, test)                                # linear_logistic_loss
        acc1 = linear_LR(train, test, sample_weight=sample_weight)   # IW

        clean_train = relative_density(train)                        # RD
        acc2 = linear_LR(clean_train, test)

        acc3 = relative_proba_density(train, test, method="linear_LR", rpd_method="KLIEP",
                                      sigma_chosen=sigma_chosen)     # kRPD
        acc4 = relative_proba_density(train, test, method="linear_LR",
                                      rpd_method="classifier")       # cRPD

        temp_acc.append([acc0, acc1, acc2, acc3, acc4])
        print("lr:", acc0, "iw:", acc1, "rd:", acc2, "krpd:", acc3, "crpd:", acc4)

    mean_acc = np.mean(temp_acc, axis=0)
    std_acc = np.round(np.std(temp_acc, axis=0), 2)

    round_acc = np.round(mean_acc, 2)

    print("LR:%.2lf±%.2lf" % (round_acc[0], std_acc[0]), "IW:%.2lf±%.2lf" % (round_acc[1], std_acc[1]),
          "RD:%.2lf±%.2lf" % (round_acc[2], std_acc[2]), "kRPD:%.2lf±%.2lf" % (round_acc[3], std_acc[3]),
          "cRPD:%.2lf±%.2lf" % (round_acc[4], std_acc[4]))
    print()

    return mean_acc, std_acc




def main(sigma_chosen=1):

    import warnings
    warnings.filterwarnings("ignore")

    keys = ["breastcancer", "diabetes", "german", "heart", "image", "thyroid"]
    noises = [(0.2, 0.2), (0.3, 0.1), (0.4, 0.4)]

    acc_all = []
    std_all = []
    for key in keys:
        for noise in noises:

            mean_acc, std_acc = main_train(key, noise, sigma_chosen=sigma_chosen)
            acc_all.append(mean_acc)
            std_all.append(std_acc)

    mean = np.round(np.mean(acc_all, axis=0), 2)
    mean_all = np.round(acc_all, 2)

    temp_all = []
    for i, j in zip(mean_all, std_all):

        result0 = "%.2lf ± %.2lf" % (i[0], j[0])
        result1 = "%.2lf ± %.2lf" % (i[1], j[1])
        result2 = "%.2lf ± %.2lf" % (i[2], j[2])
        result3 = "%.2lf ± %.2lf" % (i[3], j[3])
        result4 = "%.2lf ± %.2lf" % (i[4], j[4])
        result = [result0, result1, result2, result3, result4]
        temp_all.append(result)

    temp_all.append(list(mean))
    temp_all = pd.DataFrame(temp_all, columns=["LR", "IW", "RD", "kRPD", "cRPD"])
    temp_all.to_csv(r"../record_data//%d_linear_LR_.csv" % (sigma_chosen), index=False)

    print("LR_mean:", mean[0], "IW_mean:", mean[1], "RD_mean:", mean[2], "kRPD_mean:", mean[3], "cRPD_mean:", mean[4])
    print()




if __name__=="__main__":

    sigma_chosens = np.logspace(0, 8, 9, base=2)
    for sigma_chosen in sigma_chosens:
        print("当前核宽度为：", sigma_chosen)
        main(sigma_chosen=sigma_chosen)
        print()

