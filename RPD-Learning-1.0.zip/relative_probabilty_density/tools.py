from relative_probabilty_density.kliep import KLIEP
from sklearn.model_selection import train_test_split
import numpy as np
"""
函数功能：
1.添加翻转噪声
2.导入数据集
3.importance reweighting(简称IW)方法的实现
"""



def add_flip_noise(dataset, noise_rate):
    """添加翻转噪声"""

    samples_num = dataset.shape[0]
    positive_num = np.count_nonzero(dataset[:, 0] == 1)  # +1类数据的数量
    negative_num = np.count_nonzero(dataset[:, 0] == -1) # -1类数据的数量

    m = int(positive_num * noise_rate[0])
    n = int(negative_num * noise_rate[1])
    noise_index_list = []                                # 记录所有噪声的下标

    p_index = 0
    n_index = 0
    np.random.seed()

    while True:
        rand_index = int(np.random.uniform(0, samples_num)) # 随机选择下标

        if rand_index in noise_index_list:
            continue

        if dataset[rand_index, 0] == 1 and p_index < m:
            dataset[rand_index, 0] = -1
            p_index += 1
            noise_index_list.append(rand_index)

        elif dataset[rand_index, 0] == -1 and n_index < n:
            dataset[rand_index, 0] = 1
            n_index += 1
            noise_index_list.append(rand_index)

        if p_index >= m and n_index >= n:
            break

    return dataset




def load_data(key, test_rate=0.25, noise_rate=(0.2, 0.2)):
    """Import dataset and add filpped noise"""

    import scipy.io as sio
    path = "..\dataset"
    data = sio.loadmat(path+"/dataset.mat")
    data = data[key]
    train, test = train_test_split(data, test_size=test_rate)

    if noise_rate[0] != 0 or noise_rate[1] != 0:
        train = add_flip_noise(train, noise_rate)  # 添加翻转噪声
    return train, test



def cal_density_ratio_KL(train, sigma_chosen=1):
    """The density ratio is obtained by KLIEP"""

    def KLIEP_negative(train, sigma_chosen=1):

        model = KLIEP()
        train_1 = train[train[:, 0] == -1, 1:]
        train_set = train[:, 1:]
        train_1 = train_1.T
        train_set = train_set.T
        weight, _ = model.fit(train_1, train_set, sigma_chosen=sigma_chosen)
        return weight

    def KLIEP_positive(train, sigma_chosen=1):

        model = KLIEP()
        train_1 = train[train[:, 0] == 1, 1:]
        train_set = train[:, 1:]
        train_1 = train_1.T
        train_set = train_set.T

        weight, _ = model.fit(train_1, train_set, sigma_chosen=sigma_chosen)
        return weight

    weight_1 = KLIEP_negative(train, sigma_chosen=sigma_chosen) # y=-1
    weight_2 = KLIEP_positive(train, sigma_chosen=sigma_chosen) # y=1

    density_ratio = []
    w1 = 0
    w2 = 0
    for i in range(train.shape[0]):
        if train[i, 0] == 1:
            density_ratio.append(weight_2[w2])
            w2 += 1
        elif train[i, 0] == -1:
            density_ratio.append(weight_1[w1])
            w1 += 1
    density_ratio = np.array(density_ratio)
    density_ratio = np.reciprocal(density_ratio)        # 求倒数
    return density_ratio



def cal_density_Y(train):
    """Y=+1类的结果在前，Y=-1类的结果在后"""

    density_y = []
    sample_nums = train.shape[0]

    posi_num = np.count_nonzero(train[:, 0] == 1)
    nega_num = np.count_nonzero(train[:, 0] == -1)

    density_y.append(float(posi_num / sample_nums))
    density_y.append(float(nega_num / sample_nums))
    return density_y



def cal_cond_proba(train, sigma_chosen=1):
    """计算条件概率"""

    condtional_proba = []

    density_ratio = cal_density_ratio_KL(train, sigma_chosen=sigma_chosen)  # 计算权重
    density_y = cal_density_Y(train)                  # 计算density_y，(Y=+1,Y=- 1)

    for i in range(len(train)):
        if train[i, 0] == -1:
            subelement_result = density_ratio[i] * density_y[1]
        else:
            subelement_result = density_ratio[i] * density_y[0]
        condtional_proba.append(subelement_result)

    condtional_proba = np.array(condtional_proba)        # 这里的条件概率为(m, )
    return condtional_proba



def cal_sample_weight(data, true_noise, sigma_chosen=1):
    """计算importance reweighting中的权重"""

    condition_proba = cal_cond_proba(data, sigma_chosen=sigma_chosen)   # 计算条件概率
    labels_noise = true_noise
    nu = []    # 计算分子
    de = []    # 计算分母

    temp = 1 - labels_noise[0] - labels_noise[1]
    for i in range(len(condition_proba)):

        if condition_proba[i] != 0:
            if data[i, 0] == 1:
                nu.append(condition_proba[i] - labels_noise[1])
                de.append(temp * condition_proba[i])

            elif data[i, 0] == -1:
                nu.append(condition_proba[i] - labels_noise[0])
                de.append(temp * condition_proba[i])
        else:   # 若条件概率为0，则beta则为0
            nu.append(0)
            de.append(1)

    nu = np.array(nu)
    de = np.array(de)
    sample_weight = nu / de
    return sample_weight
