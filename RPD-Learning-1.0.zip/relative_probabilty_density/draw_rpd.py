from relative_probabilty_density.relative_probability_density import cal_rpd_classifier,cal_rpd_kliep
from sklearn.datasets import make_classification
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
"""
函数功能：求出每个样本（人造数据集）的RPD值，然后画出散点图
"""



def make_artifical_data():
    """制造人为数据集"""

    data, labels = make_classification(n_samples=30, n_features=2, n_informative=1, n_classes=2,
                                       random_state=None, n_redundant=0, n_clusters_per_class=1,
                                       n_repeated=0, class_sep=0.95)
    data = pd.DataFrame(data, columns=["attr_1", "attr_2"])
    data["label"] = labels
    data.to_csv("../dataset/synthetic_data_1.csv", index=False)

    posi_data = data.loc[data["label"] == 1, :]
    nega_data = data.loc[data["label"] == 0, :]

    plt.scatter(posi_data["attr_1"], posi_data["attr_2"], label="positive")
    plt.scatter(nega_data["attr_1"], nega_data["attr_2"], label="negative")
    plt.legend()
    plt.show()




def add_flip_noise(dataset, noise_index):
    """添加翻转噪声"""

    samples_num = len(dataset)
    np.random.seed()

    for i in range(samples_num):
        if i in noise_index:
            if dataset.loc[i, "label"] == 1:
                dataset.loc[i, "label"] = -1
            else:
                dataset.loc[i, "label"] = 1
    return dataset




def draw_rpd():
    """标出每个样本的RPD值"""

    data = pd.read_csv(r"../dataset/draw_rpd_dataset.csv")
    data["label"] = data["label"].apply(lambda x: -1 if x == 0 else 1) # 将标签改为-1, 1

    noise_index = [19, 1, 13, 20, 21, 6, 17, 15]             # 认为选的噪点位置
    data = add_flip_noise(data, noise_index)                 # 添加翻转噪声

    # rpd_kliep = cal_rpd_kliep(data.values)                               # 通过KLIEP求RPD
    rpd_classifier = cal_rpd_classifier(data.values, method="linear_LR")   # 通过分类器求RPD

    data["RPD"] = np.round(rpd_classifier, 2)
    clean_index = np.delete(range(len(data)), noise_index)   # 得到干净数据的索引

    clean_data = data.loc[clean_index, :]
    clean_positive_data = clean_data.loc[clean_data["label"] == 1, :]
    clean_negative_data = clean_data.loc[clean_data["label"] == -1, :]


    sign_noise_posi_data = data.loc[[13, 20], :]              # 显著性噪声
    sign_noise_nega_data = data.loc[[17, 15], :]

    non_sign_noise_posi_data = data.loc[[19, 1], :]           # 非显著性噪声
    non_sign_noise_nega_data = data.loc[[21, 6], :]


    plt.figure()
    # 绘制干净数据散点图
    plt.scatter(clean_positive_data["attr_1"], clean_positive_data["attr_2"], marker="o", c="black", label="positive", s=45)
    plt.scatter(clean_negative_data["attr_1"], clean_negative_data["attr_2"], marker="*", c="black", label="negative", s=56)

    # 绘制显著性噪声散点图
    plt.scatter(sign_noise_posi_data["attr_1"], sign_noise_posi_data["attr_2"], marker="o", c="red", label="negative significant noise", s=45)
    plt.scatter(sign_noise_nega_data["attr_1"], sign_noise_nega_data["attr_2"], marker="*", c="red", label="positive significant noise", s=56)

    # 绘制非显著性噪声散点图
    plt.scatter(non_sign_noise_posi_data["attr_1"], non_sign_noise_posi_data["attr_2"], marker="o", c="blue", label="negative non-significant noise", s=45)
    plt.scatter(non_sign_noise_nega_data["attr_1"], non_sign_noise_nega_data["attr_2"], marker="*", c="blue", label="positive non-significant noise", s=56)

    # 为每个样本添加RPD值
    for i in range(len(data)):
        plt.text(data.loc[i, "attr_1"]+0.050, data.loc[i, "attr_2"]-0.04, data.loc[i, "RPD"])

    plt.legend(fontsize=10)
    plt.xlim(-2.8, 2.5)
    plt.show()




if __name__ == '__main__':
    draw_rpd()

