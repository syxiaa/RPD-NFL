from relative_probabilty_density.relative_probability_density import relative_proba_density
from relative_probabilty_density.tools import add_flip_noise, cal_sample_weight
from relative_probabilty_density.relative_density import relative_density
from relative_probabilty_density.linear_logistic_loss import linear_LR
from relative_probabilty_density.linear_hinge_loss import linear_svm
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_classification
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
"""
函数功能
1.linear-LR,IW,RD,kRPD,cRPD在人造数据集上准确率对比
2.linear-SVM,IW,RD,kRPD,cRPD在人造数据集上准确率对比
备注：此函数需要2个文件夹，用于存储实验数据
"""


def make_synthetic_data():
    """创建人造数据集"""

    dataset, labels = make_classification(n_samples=1000, n_features=2, n_informative=1, n_classes=2,
                                          random_state=None, n_redundant=0, n_clusters_per_class=1,
                                          n_repeated=0, class_sep=0.95)
    data_1 = dataset[labels == 0, :]
    data_2 = dataset[labels == 1, :]
    labels = labels.reshape(-1, 1)
    labels[labels[:] == 0] = -1
    dataset = np.hstack((labels, dataset))

    np.savetxt(r"../dataset/synthetic_data_2.csv", dataset, delimiter=",", fmt="%s")
    # print("类别个数分别为：", len(data_1), len(data_2))
    # plt.scatter(data_1[:, 0], data_1[:, 1], label="negative")
    # plt.scatter(data_2[:, 0], data_2[:, 1], label="positive")
    # plt.legend()
    # plt.show()
    return dataset




def load_data(noise, test_size=0.25):
    """导入人造数据，并且添加标签噪声"""

    dataset = pd.read_csv(r"../dataset//synthetic_data.csv")
    dataset = np.array(dataset)
    train, test = train_test_split(dataset, test_size=test_size)
    if noise[0] or noise[1]:
        train = add_flip_noise(train, noise)
    return train, test



def linear_LR_train(noise, sigma_chosen=1, divide_num=10):
    """线性逻辑回归在指定噪声率下，准确率对比"""

    temp_acc = []
    print("噪声率为：", noise)
    for i in range(divide_num):

        train, test = load_data(noise)
        sample_weight = cal_sample_weight(train, noise, sigma_chosen=sigma_chosen)

        acc0 = linear_LR(train, test)                                  # linear-LR
        acc1 = linear_LR(train, test, sample_weight=sample_weight)     # IW

        clean_train = relative_density(train)                          # RD
        acc2 = linear_LR(clean_train, test)

        acc3 = relative_proba_density(train, test, method="linear_LR", rpd_method="KLIEP", sigma_chosen=sigma_chosen) # kRPD
        acc4 = relative_proba_density(train, test, method="linear_LR", rpd_method="classifier")                       # cRPD

        temp_acc.append([acc0, acc1, acc2, acc3, acc4])
        print("lr:", acc0, "iw:", acc1, "rd:", acc2, "krpd:", acc3, "crpd:", acc4)

    mean_acc = np.mean(temp_acc, axis=0)
    std_acc = np.round(np.std(temp_acc, axis=0), 2)
    round_acc = np.round(mean_acc, 2)

    print("LR:%.2lf±%.2lf" % (round_acc[0], std_acc[0]), "IW:%.2lf±%.2lf" % (round_acc[1], std_acc[1]),
          "RD:%.2lf±%.2lf" % (round_acc[2], std_acc[2]), "kRPD:%.2lf±%.2lf" % (round_acc[3], std_acc[3]),
          "cRPD:%.2lf±%.2lf" % (round_acc[4], std_acc[4]))
    print()
    print()
    return mean_acc




def linear_LR_main(sigma_chosen=1):
    """记录线性逻辑回归实验数据的主函数"""

    import warnings
    warnings.filterwarnings("ignore")
    noise = [(0.1, 0.1), (0.2, 0.2), (0.3, 0.1), (0.1, 0.3), (0.3, 0.3), (0.4, 0.4)]
    acc_all = []
    for i in range(len(noise)):

        mean_acc = linear_LR_train(noise[i], sigma_chosen=sigma_chosen)
        acc_all.append(mean_acc)

    acc_all = np.array(acc_all)
    print("LR_%d:" % (sigma_chosen), acc_all)
    head = np.array(["LR", "IW", "RD", "kRPD", "cRPD"])
    acc_all = np.vstack((head, acc_all))
    np.savetxt(r"../record_data//Fig_linear_LR_accuracy_%d.csv" % (sigma_chosen), acc_all, delimiter=",", fmt="%s")
    print()






def linear_SVM_train(noise, sigma_chosen=1, divide_num=10):
    """线性支持向量机在指定噪声率下，准确率对比"""

    temp_acc = []
    print("噪声率为：", noise)
    for i in range(divide_num):
        train, test = load_data(noise)
        sample_weight = cal_sample_weight(train, noise, sigma_chosen=sigma_chosen)

        acc0 = linear_svm(train, test)
        acc1 = linear_svm(train, test, sample_weight=sample_weight)

        new_train = relative_density(train)
        acc2 = linear_svm(new_train, test)

        acc3 = relative_proba_density(train, test, method="linear_SVM", rpd_method="KLIEP", sigma_chosen=sigma_chosen)
        acc4 = relative_proba_density(train, test, method="linear_SVM", rpd_method="classifier")

        temp_acc.append([acc0, acc1, acc2, acc3, acc4])
        print("lsvm:", acc0, "iw:", acc1, "rd:", acc2, "krpd:", acc3, "crpd:", acc4)

    mean_acc = np.mean(temp_acc, axis=0)
    std_acc = np.round(np.std(temp_acc, axis=0), 2)
    round_acc = np.round(mean_acc, 2)

    print("LSVM:%.2lf±%.2lf" % (round_acc[0], std_acc[0]), "IW:%.2lf±%.2lf" % (round_acc[1], std_acc[1]),
          "RD:%.2lf±%.2lf" % (round_acc[2], std_acc[2]), "kRPD:%.2lf±%.2lf" % (round_acc[3], std_acc[3]),
          "cRPD:%.2lf±%.2lf" % (round_acc[4], std_acc[4]))
    print()

    return mean_acc




def linear_SVM_main(sigma_chosen=1):
    """记录线性支持向量机实验数据主函数"""

    import warnings
    warnings.filterwarnings("ignore")

    noise = [(0.1, 0.1), (0.2, 0.2), (0.3, 0.1), (0.1, 0.3), (0.3, 0.3), (0.4, 0.4)]
    acc_all = []
    for i in range(len(noise)):

        mean_acc = linear_SVM_train(noise[i], sigma_chosen=sigma_chosen)
        acc_all.append(mean_acc)

    acc_all = np.array(acc_all)
    print("svm_%d:"%(sigma_chosen),acc_all)
    head = np.array(["LSVM", "IW", "RD", "kRPD", "cRPD"])
    acc_all = np.vstack((head, acc_all))
    np.savetxt(r"..//record_data//Fig_linear_SVM_accuracy_%d.csv" % (sigma_chosen), acc_all, delimiter=",", fmt="%s")
    print()




def plot_logistic(sigma_chosen):
    """绘制画线性逻辑回归方法准确率对比图"""

    data = pd.read_csv(r"../record_data/Fig_linear_LR_accuracy_%d.csv"%(sigma_chosen))
    data = data / 100
    x = range(1, 7)

    plt.figure()
    plt.plot(x, data["cRPD"], "-", c="black", label="cRPD with logistic loss and given noise rates")
    plt.plot(x, data["kRPD"], "-", c="red", label="kRPD with logistic loss and given noise rates")
    plt.plot(x, data["IW"], "--", c="black", label="IW with logistic loss and given noise rates")
    plt.plot(x, data["RD"], "--s", c="blue", label="RD with logistic loss and given noise rates")
    plt.plot(x, data["LR"], ":", c="red", label="Logistic classification")
    plt.xlim(1, 6)
    plt.yticks([0.88, 0.90, 0.92, 0.94, 0.96, 0.98, 1])
    plt.xlabel("Different noise pairs", fontsize=14)
    plt.ylabel("Classification accuracy", fontsize=14)
    plt.legend(fontsize=10)
    # plt.savefig("../image/logistic_%d.svg"%(sigma_chosen))
    # plt.show()




def plot_hinge(sigma_chosen=1):
    """绘制画线性支持向量机方法准确率对比图"""

    data = pd.read_csv("../record_data/Fig_linear_SVM_accuracy_%d.csv" % (sigma_chosen))
    data = data / 100
    x = range(1, 7)

    plt.figure()
    plt.plot(x, data["cRPD"], "-", c="black", label="cRPD with hinge loss and given noise rates")
    plt.plot(x, data["kRPD"], "-", c="red", label="kRPD with hinge loss and given noise rates")
    plt.plot(x, data["IW"], "--", c="black", label="IW with hinge loss and given noise rates")
    plt.plot(x, data["RD"], "--s", c="blue", label="RD with hinge loss and given noise rates")
    plt.plot(x, data["LSVM"], ":", c="red", label="SVM")
    plt.xlim(1, 6)
    plt.yticks([0.88, 0.90, 0.92, 0.94, 0.96, 0.98, 1])
    plt.xlabel("Different noise pairs", fontsize=14)
    plt.ylabel("Classification accuracy", fontsize=14)
    plt.legend(fontsize=10)
    # plt.savefig("../image/hinge_%d.svg"%(sigma_chosen))
    # plt.show()


def main():
    """主函数，在不同的核宽度下，绘制线性逻辑回归、线性支持向量机准确率对比图"""
    import warnings
    warnings.filterwarnings("ignore")

    sigma_chosens = np.logspace(0, 8, 9, base=2)
    for sigma_chosen in sigma_chosens:
        print("当前核宽度为：", sigma_chosen)
        print("正在使用：logistic-loss")
        linear_LR_main(sigma_chosen)
        plot_logistic(sigma_chosen)

        print("当前核宽度为：", sigma_chosen)
        print("正在使用：hinge-loss")
        linear_SVM_main(sigma_chosen)
        plot_hinge(sigma_chosen)
        print()
        print()
    plt.show()

if __name__ == '__main__':
    main()

